# CTL Dumpster Tracker

Starter iPhone app for CTL Roll Offs built with SwiftUI.

## Included
- Spanish and English interface
- Dashboard with available/rented/pickup-today/overdue counts
- Dumpster inventory
- Physical dumpster size separated from rented-as size
- Fill-limit tracking (for example: physical 15 yd rented as 10 yd with 10 yd fill limit)
- Weight allowance and rental price
- Customer, phone, address, dates and notes
- Mark a rental picked up and return the physical dumpster to available inventory
- Simple on-device persistence using UserDefaults

## Open in Xcode
1. Unzip the folder on your Mac.
2. Open `CTLTracker.xcodeproj`.
3. Select the `CTLTracker` target.
4. Under Signing & Capabilities, choose your Apple Developer team.
5. Change the bundle identifier if Xcode asks you to.
6. Connect your iPhone, select it as the run destination, and press Run.

This is a starter version. Maps/GPS, cloud sync, photo proof, invoices, employees, notifications and automatic late/overweight fees can be added next.
