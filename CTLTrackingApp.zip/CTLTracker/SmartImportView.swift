import SwiftUI
import PhotosUI
import Vision
import UIKit

struct SmartImportView: View {
    @EnvironmentObject var store: DumpsterStore
    @State private var selectedPhotos: [PhotosPickerItem] = []
    @State private var results: [SmartImportResult] = []
    @State private var isProcessing = false
    @State private var message: String?
    @State private var combineForOneRental = true

    var body: some View {
        List {
            Section {
                Toggle("smart_import_combine", isOn: $combineForOneRental)

                PhotosPicker(selection: $selectedPhotos, maxSelectionCount: 20, matching: .images) {
                    HStack {
                        Image(systemName: "photo.stack.fill")
                        Text(selectedPhotos.isEmpty ? L10n.string("smart_import_choose") : "\(selectedPhotos.count) \(L10n.string("smart_import_selected"))")
                    }
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
                }
                .buttonStyle(.borderedProminent)
                .tint(Color.ctlRed)

                if isProcessing {
                    HStack(spacing: 10) {
                        ProgressView()
                        Text("smart_import_combining")
                            .foregroundStyle(.secondary)
                    }
                }
                if let message {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            } header: {
                Text("smart_import_title")
            } footer: {
                Text("smart_import_combined_help")
            }

            if !results.isEmpty {
                Section("smart_import_results") {
                    ForEach($results) { $result in
                        SmartImportResultCard(result: $result)
                    }
                    Button(role: .destructive) { results.removeAll() } label: {
                        Label("smart_import_clear", systemImage: "trash")
                    }
                }
            }
        }
        .navigationTitle("smart_import_nav")
        .keyboardDoneToolbar()
        .ctlLogoToolbar()
        .onChange(of: selectedPhotos) { _, newItems in
            guard !newItems.isEmpty else { return }
            Task { await process(newItems) }
        }
    }

    @MainActor
    private func process(_ items: [PhotosPickerItem]) async {
        isProcessing = true
        message = nil
        var recognizedTexts: [String] = []

        for item in items {
            do {
                guard let data = try await item.loadTransferable(type: Data.self) else { continue }
                let text = try await ScreenshotTextRecognizer.recognize(data: data)
                if !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    recognizedTexts.append(text)
                }
            } catch {
                message = L10n.string("smart_import_some_failed")
            }
        }

        if combineForOneRental {
            let combined = recognizedTexts.enumerated().map { index, text in
                "--- SCREENSHOT \(index + 1) ---\n\(text)"
            }.joined(separator: "\n\n")
            if !combined.isEmpty {
                var result = SmartRentalParser.parse(text: combined)
                result.sourceImageCount = recognizedTexts.count
                result.suggestedDumpsterID = suggestedDumpster(for: result)?.id
                results.append(result)
            }
        } else {
            for text in recognizedTexts {
                var result = SmartRentalParser.parse(text: text)
                result.sourceImageCount = 1
                result.suggestedDumpsterID = suggestedDumpster(for: result)?.id
                results.append(result)
            }
        }

        if recognizedTexts.isEmpty {
            message = L10n.string("smart_import_no_text")
        } else if combineForOneRental {
            message = "\(recognizedTexts.count) \(L10n.string("smart_import_combined_message"))"
        }

        isProcessing = false
        selectedPhotos = []
    }

    private func suggestedDumpster(for result: SmartImportResult) -> Dumpster? {
        let requested = result.rentedAs > 0 ? result.rentedAs : result.fillLimit
        let available = store.dumpsters.filter { $0.status == .available }
        if requested > 0 {
            return available
                .filter { $0.physicalSize >= requested }
                .sorted { $0.physicalSize < $1.physicalSize }
                .first
        }
        return nil
    }
}

struct SmartImportResultCard: View {
    @EnvironmentObject var store: DumpsterStore
    @Binding var result: SmartImportResult
    @State private var saved = false

    private var available: [Dumpster] { store.dumpsters.filter { $0.status == .available } }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Label(result.category.title, systemImage: result.category.icon)
                    .font(.title3.bold())
                    .foregroundStyle(Color.ctlRed)
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text("\(Int(result.confidence * 100))%")
                        .font(.caption.bold())
                    Text("\(result.sourceImageCount) \(L10n.string(result.sourceImageCount == 1 ? "smart_import_image" : "smart_import_images"))")
                        .font(.caption2)
                }
                .foregroundStyle(.secondary)
            }

            importTextField(L10n.string("smart_name"), text: $result.customerName)
            importTextField(L10n.string("smart_phone"), text: $result.phone, keyboard: .phonePad)
            importTextField(L10n.string("smart_address"), text: $result.address, axis: .vertical)

            VStack(spacing: 10) {
                IntegerInputField(title: "rented_as", value: $result.rentedAs, suffix: L10n.string("yards"), range: 0...60)
                IntegerInputField(title: "fill_limit", value: $result.fillLimit, suffix: L10n.string("yards"), range: 0...60)
                DecimalInputField(title: "weight_included", value: $result.weightTons, suffix: L10n.string("tons"), range: 0...20, decimalPlaces: 2)
                DecimalInputField(title: "price", value: $result.price, prefix: "$", range: 0...100000, decimalPlaces: 2)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("smart_suggested_dumpster")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Picker("smart_import_assign", selection: $result.suggestedDumpsterID) {
                    Text("smart_import_no_dumpster").tag(UUID?.none)
                    ForEach(available) { d in
                        Text("\(d.number) · \(d.physicalSize) \(L10n.string("yards"))")
                            .tag(Optional(d.id))
                    }
                }
                .pickerStyle(.menu)
                .tint(Color.ctlRed)
            }

            DatePicker("dropoff_date", selection: $result.dropOffDate, displayedComponents: .date)
            DatePicker("pickup_date", selection: $result.pickupDate, displayedComponents: .date)
            importTextField(L10n.string("smart_notes"), text: $result.notes, axis: .vertical)

            DisclosureGroup("smart_import_ocr_text") {
                Text(result.rawText)
                    .font(.caption.monospaced())
                    .textSelection(.enabled)
                    .foregroundStyle(.secondary)
                    .padding(.top, 6)
            }

            Button {
                saveResult()
            } label: {
                Label(saved ? "smart_import_saved" : "smart_import_save", systemImage: saved ? "checkmark.circle.fill" : "tray.and.arrow.down.fill")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)
            .tint(saved ? .green : Color.ctlRed)
            .disabled(saved)
        }
        .padding(.vertical, 10)
    }

    @ViewBuilder
    private func importTextField(_ title: String, text: Binding<String>, keyboard: UIKeyboardType = .default, axis: Axis = .horizontal) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            TextField(L10n.string("not_found_placeholder"), text: text, axis: axis)
                .keyboardType(keyboard)
                .textFieldStyle(.plain)
                .padding(12)
                .background(Color.secondary.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 10))
        }
    }

    private func saveResult() {
        let name = cleaned(result.customerName)
        let phone = cleaned(result.phone)
        let address = cleaned(result.address)

        if let name, !store.customers.contains(where: {
            $0.name.caseInsensitiveCompare(name) == .orderedSame && $0.phone == (phone ?? "")
        }) {
            store.addCustomer(Customer(name: name, phone: phone ?? "", address: address ?? "", notes: result.notes))
        }

        if let id = result.suggestedDumpsterID,
           var dumpster = store.dumpsters.first(where: { $0.id == id && $0.status == .available }) {
            dumpster.rentedAs = result.rentedAs > 0 ? result.rentedAs : nil
            dumpster.fillLimit = result.fillLimit > 0 ? result.fillLimit : (result.rentedAs > 0 ? result.rentedAs : nil)
            dumpster.weightAllowanceTons = result.weightTons > 0 ? result.weightTons : nil
            dumpster.price = result.price > 0 ? result.price : nil
            dumpster.customerName = name
            dumpster.phone = phone
            dumpster.address = address
            dumpster.dropOffDate = result.dropOffDate
            dumpster.pickupDate = result.pickupDate
            dumpster.notes = result.notes
            dumpster.status = Calendar.current.isDateInToday(result.pickupDate) ? .pickupToday : (result.pickupDate < Calendar.current.startOfDay(for: Date()) ? .overdue : .rented)
            store.update(dumpster)
        }
        saved = true
    }

    private func cleaned(_ value: String) -> String? {
        let text = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.caseInsensitiveCompare("N/A") != .orderedSame else { return nil }
        return text
    }
}

struct SmartImportResult: Identifiable {
    enum Category: String {
        case rental, customer, pickup, unknown
        var title: LocalizedStringKey {
            switch self {
            case .rental: return "smart_category_rental"
            case .customer: return "smart_category_customer"
            case .pickup: return "smart_category_pickup"
            case .unknown: return "smart_category_unknown"
            }
        }
        var icon: String {
            switch self {
            case .rental: return "shippingbox.fill"
            case .customer: return "person.crop.circle.fill"
            case .pickup: return "truck.box.fill"
            case .unknown: return "questionmark.circle.fill"
            }
        }
    }

    let id = UUID()
    var category: Category
    var confidence: Double
    var customerName: String
    var phone: String
    var address: String
    var rentedAs: Int
    var fillLimit: Int
    var weightTons: Double
    var price: Double
    var dropOffDate: Date
    var pickupDate: Date
    var notes: String
    var suggestedDumpsterID: UUID?
    var rawText: String
    var sourceImageCount: Int = 1
}

enum ScreenshotTextRecognizer {
    static func recognize(data: Data) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            guard let image = UIImage(data: data), let cgImage = image.cgImage else {
                continuation.resume(throwing: ImportError.invalidImage)
                return
            }
            let request = VNRecognizeTextRequest { request, error in
                if let error { continuation.resume(throwing: error); return }
                let observations = request.results as? [VNRecognizedTextObservation] ?? []
                let lines = observations.compactMap { $0.topCandidates(1).first?.string }
                continuation.resume(returning: lines.joined(separator: "\n"))
            }
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true
            request.recognitionLanguages = ["en-US", "es-US", "es-MX"]
            DispatchQueue.global(qos: .userInitiated).async {
                do { try VNImageRequestHandler(cgImage: cgImage).perform([request]) }
                catch { continuation.resume(throwing: error) }
            }
        }
    }

    enum ImportError: Error { case invalidImage }
}

enum SmartRentalParser {
    static func parse(text: String) -> SmartImportResult {
        let lines = text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty && !$0.hasPrefix("--- SCREENSHOT") }
        let lower = text.lowercased()

        let category: SmartImportResult.Category
        if containsAny(lower, ["pickup", "pick up", "recogida", "remove dumpster", "haul away"]) { category = .pickup }
        else if containsAny(lower, ["dumpster", "rental", "rent", "yard", "yd", "contenedor", "renta"]) { category = .rental }
        else if containsAny(lower, ["customer", "cliente", "phone", "teléfono", "telefono"]) { category = .customer }
        else { category = .unknown }

        let phone = firstMatch(in: text, pattern: #"(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}"#) ?? ""
        let priceString = firstMatch(in: text, pattern: #"\$\s?\d{2,5}(?:\.\d{2})?"#)?
            .replacingOccurrences(of: "$", with: "")
            .trimmingCharacters(in: .whitespaces)
        let price = priceString.flatMap(Double.init)

        let yardText = firstMatch(in: lower, pattern: #"\b(10|12|15|18|20|25|30|40)\s*(?:yd|yard|yards|yarda|yardas)\b"#)
        let rentedAs = yardText.flatMap { firstMatch(in: $0, pattern: #"\d+"#) }.flatMap(Int.init)

        let fillMatch = firstMatch(in: lower, pattern: #"(?:fill\s*limit|l[ií]mite\s*(?:de\s*)?llenado)[^\d]{0,12}(\d{1,2})"#)
        let fillLimit = fillMatch.flatMap { firstMatch(in: $0, pattern: #"\d+"#) }.flatMap(Int.init) ?? rentedAs

        let weightMatch = firstMatch(in: lower, pattern: #"(\d+(?:\.\d+)?)\s*(?:ton|tons|tonelada|toneladas)"#)
        let weightTons = weightMatch.flatMap { firstMatch(in: $0, pattern: #"\d+(?:\.\d+)?"#) }.flatMap(Double.init)

        let address = lines.first(where: { line in
            line.range(of: #"\b\d{1,6}\s+[A-Za-z0-9 .'-]+\b(?:St|Street|Ave|Avenue|Rd|Road|Dr|Drive|Ln|Lane|Ct|Court|Blvd|Boulevard|Way|Pl|Place|Cir|Circle)\b"#, options: [.regularExpression, .caseInsensitive]) != nil
        }) ?? ""

        let excluded = [phone, address].filter { !$0.isEmpty }
        let name = lines.first(where: { candidate in
            isLikelyPersonName(candidate, excluded: excluded)
        }) ?? ""

        let dateMatches = allMatches(in: text, pattern: #"\b(?:0?[1-9]|1[0-2])[/-](?:0?[1-9]|[12]\d|3[01])[/-](?:\d{2}|\d{4})\b"#)
        let dates = dateMatches.compactMap(parseDate)
        let drop = dates.first ?? Date()
        let pickup = dates.dropFirst().first ?? Calendar.current.date(byAdding: .day, value: 7, to: drop) ?? drop

        var confidence = 0.20
        if !phone.isEmpty { confidence += 0.18 }
        if !address.isEmpty { confidence += 0.22 }
        if !name.isEmpty { confidence += 0.18 }
        if rentedAs != nil { confidence += 0.12 }
        if price != nil { confidence += 0.10 }

        return SmartImportResult(
            category: category,
            confidence: min(confidence, 0.98),
            customerName: name,
            phone: phone,
            address: address,
            rentedAs: rentedAs ?? 0,
            fillLimit: fillLimit ?? rentedAs ?? 0,
            weightTons: weightTons ?? 0,
            price: price ?? 0,
            dropOffDate: drop,
            pickupDate: pickup,
            notes: category == .unknown ? "" : L10n.string("smart_import_note"),
            suggestedDumpsterID: nil,
            rawText: text,
            sourceImageCount: 1
        )
    }

    private static func isLikelyPersonName(_ line: String, excluded: [String]) -> Bool {
        guard !excluded.contains(line), line.count >= 3, line.count <= 40 else { return false }
        guard line.rangeOfCharacter(from: .decimalDigits) == nil else { return false }
        let words = line.split(separator: " ")
        guard (2...4).contains(words.count) else { return false }
        let lower = line.lowercased()
        let rejectWords = [
            "how ", "what ", "when ", "where ", "why ", "can ", "could ", "would ", "do ", "does ", "did ",
            "dumpster", "rental", "invoice", "receipt", "order", "delivery", "pickup", "yard", "contenedor", "renta",
            "total", "price", "address", "phone", "date", "available", "sides", "high", "fill", "weight", "tons"
        ]
        guard !rejectWords.contains(where: { lower.contains($0) }) else { return false }
        return words.allSatisfy { word in
            word.allSatisfy { $0.isLetter || $0 == "-" || $0 == "'" }
        }
    }

    private static func containsAny(_ text: String, _ words: [String]) -> Bool { words.contains { text.contains($0) } }

    private static func firstMatch(in text: String, pattern: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let match = regex.firstMatch(in: text, range: range), let r = Range(match.range, in: text) else { return nil }
        return String(text[r])
    }

    private static func allMatches(in text: String, pattern: String) -> [String] {
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        return regex.matches(in: text, range: range).compactMap { match in
            guard let r = Range(match.range, in: text) else { return nil }
            return String(text[r])
        }
    }

    private static func parseDate(_ value: String) -> Date? {
        for format in ["M/d/yyyy", "MM/dd/yyyy", "M/d/yy", "MM/dd/yy"] {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = format
            if let date = formatter.date(from: value) { return date }
        }
        return nil
    }
}
