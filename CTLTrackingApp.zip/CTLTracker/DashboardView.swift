import SwiftUI

struct DashboardView: View {
    @EnvironmentObject var store: DumpsterStore
    @State private var showingNewRental = false

    private let columns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Image("HeaderLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 260, maxHeight: 120)
                    .frame(maxWidth: .infinity)
                    .accessibilityLabel("CTL Roll Offs")

                Text("hello_cesar").font(.title2.bold())
                Text("dashboard_subtitle").foregroundStyle(.secondary)

                LazyVGrid(columns: columns, spacing: 12) {
                    MetricCard(value: store.availableCount, title: "metric_available", icon: "checkmark.circle.fill")
                    MetricCard(value: store.rentedCount, title: "metric_rented", icon: "truck.box.fill")
                    MetricCard(value: store.pickupTodayCount, title: "metric_pickup_today", icon: "calendar.badge.clock")
                    MetricCard(value: store.overdueCount, title: "metric_overdue", icon: "exclamationmark.triangle.fill")
                }

                Button { showingNewRental = true } label: {
                    Label("new_rental", systemImage: "plus")
                        .font(.headline).frame(maxWidth: .infinity).padding()
                }
                .buttonStyle(.borderedProminent).tint(Color.ctlRed)

                Text("recent_rentals").font(.headline)
                ForEach(store.dumpsters.filter { $0.status != .available }.prefix(4)) { dumpster in
                    NavigationLink(value: dumpster) { RentalRow(dumpster: dumpster) }
                        .buttonStyle(.plain)
                }
            }
            .padding()
        }
        .background(Color.ctlBackground)
        .navigationDestination(for: Dumpster.self) { DumpsterDetailView(dumpster: $0) }
        .sheet(isPresented: $showingNewRental) { NavigationStack { NewRentalView() } }
    }
}

private struct MetricCard: View {
    let value: Int
    let title: LocalizedStringKey
    let icon: String
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon).font(.title2)
            Text("\(value)").font(.largeTitle.bold())
            Text(title).font(.subheadline.bold())
        }
        .frame(maxWidth: .infinity, minHeight: 120)
        .background(Color.ctlCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

struct RentalRow: View {
    let dumpster: Dumpster
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "shippingbox.fill").font(.title2).foregroundStyle(Color.ctlRed)
            VStack(alignment: .leading, spacing: 4) {
                Text(dumpster.number).font(.headline)
                Text(dumpster.customerName ?? L10n.string("no_customer")).font(.subheadline)
                if let address = dumpster.address { Text(address).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
            }
            Spacer()
            StatusBadge(status: dumpster.status)
        }
        .padding()
        .background(Color.ctlCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}
