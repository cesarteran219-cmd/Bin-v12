import SwiftUI

extension Color {
    static let ctlRed = Color(red: 0.96, green: 0.08, blue: 0.10)
    static let ctlCard = Color(red: 0.075, green: 0.09, blue: 0.10)
    static let ctlBackground = Color(red: 0.025, green: 0.035, blue: 0.04)
}

struct StatusBadge: View {
    let status: Dumpster.Status
    var body: some View {
        Text(LocalizedStringKey(status.key))
            .font(.caption.bold())
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(background)
            .clipShape(Capsule())
    }
    private var background: Color {
        switch status {
        case .available: return .green.opacity(0.8)
        case .rented: return Color.ctlRed
        case .pickupToday: return .yellow.opacity(0.85)
        case .overdue: return .orange.opacity(0.9)
        }
    }
}


struct IntegerInputField: View {
    let title: LocalizedStringKey
    @Binding var value: Int
    var suffix: String? = nil
    var range: ClosedRange<Int> = 0...9999

    @State private var text = ""
    @FocusState private var focused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            HStack(spacing: 8) {
                TextField("0", text: $text)
                    .keyboardType(.numberPad)
                    .font(.body.monospacedDigit())
                    .focused($focused)
                if let suffix {
                    Text(suffix).foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 12)
            .frame(minHeight: 44)
            .background(Color.secondary.opacity(0.12))
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .onAppear { text = String(value) }
        .onChange(of: text) { _, newValue in
            let cleaned = newValue.filter(\.isNumber)
            if cleaned != newValue { text = cleaned }
            if cleaned.isEmpty { return }
            if let parsed = Int(cleaned) {
                value = min(max(parsed, range.lowerBound), range.upperBound)
            }
        }
        .onChange(of: value) { _, newValue in
            if !focused { text = String(newValue) }
        }
        .onChange(of: focused) { _, isFocused in
            if !isFocused { text = String(value) }
        }
    }
}

struct DecimalInputField: View {
    let title: LocalizedStringKey
    @Binding var value: Double
    var prefix: String? = nil
    var suffix: String? = nil
    var range: ClosedRange<Double> = 0...999999
    var decimalPlaces: Int = 2

    @State private var text = ""
    @FocusState private var focused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            HStack(spacing: 8) {
                if let prefix { Text(prefix).foregroundStyle(.secondary) }
                TextField("0", text: $text)
                    .keyboardType(.decimalPad)
                    .font(.body.monospacedDigit())
                    .focused($focused)
                if let suffix { Text(suffix).foregroundStyle(.secondary) }
            }
            .padding(.horizontal, 12)
            .frame(minHeight: 44)
            .background(Color.secondary.opacity(0.12))
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .onAppear { text = formatted(value) }
        .onChange(of: text) { _, newValue in
            let cleaned = sanitize(newValue)
            if cleaned != newValue { text = cleaned }
            if cleaned.isEmpty || cleaned == "." { return }
            if let parsed = Double(cleaned) {
                value = min(max(parsed, range.lowerBound), range.upperBound)
            }
        }
        .onChange(of: value) { _, newValue in
            if !focused { text = formatted(newValue) }
        }
        .onChange(of: focused) { _, isFocused in
            if !isFocused { text = formatted(value) }
        }
    }

    private func sanitize(_ input: String) -> String {
        var output = ""
        var hasDecimal = false
        var decimals = 0
        for ch in input.replacingOccurrences(of: ",", with: ".") {
            if ch.isNumber {
                if hasDecimal {
                    guard decimals < decimalPlaces else { continue }
                    decimals += 1
                }
                output.append(ch)
            } else if ch == "." && !hasDecimal && decimalPlaces > 0 {
                hasDecimal = true
                output.append(ch)
            }
        }
        return output
    }

    private func formatted(_ number: Double) -> String {
        if decimalPlaces == 0 { return String(Int(number.rounded())) }
        let formatted = String(format: "%.*f", decimalPlaces, number)
        return formatted.replacingOccurrences(of: #"\.?0+$"#, with: "", options: .regularExpression)
    }
}

struct CTLHeaderLogo: View {
    var body: some View {
        Image("HeaderLogo")
            .resizable()
            .scaledToFit()
            .frame(width: 112, height: 46)
            .accessibilityLabel("CTL Roll Offs")
    }
}

private struct CTLLogoToolbarModifier: ViewModifier {
    func body(content: Content) -> some View {
        content.toolbar {
            ToolbarItem(placement: .principal) {
                CTLHeaderLogo()
            }
        }
    }
}

extension View {
    func ctlLogoToolbar() -> some View {
        modifier(CTLLogoToolbarModifier())
    }
}

enum L10n {
    static func string(_ key: String) -> String {
        let language = UserDefaults.standard.string(forKey: "appLanguage") ?? "es"
        guard let path = Bundle.main.path(forResource: language, ofType: "lproj"),
              let bundle = Bundle(path: path) else {
            return NSLocalizedString(key, comment: "")
        }
        return bundle.localizedString(forKey: key, value: key, table: nil)
    }
}
