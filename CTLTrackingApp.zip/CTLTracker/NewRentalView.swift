import SwiftUI

struct NewRentalView: View {
    @EnvironmentObject var store: DumpsterStore
    @Environment(\.dismiss) private var dismiss

    @State private var dumpsterID: UUID?
    @State private var packageID: UUID?
    @State private var customerID: UUID?
    @State private var rentedAs = 10
    @State private var fillLimit = 10
    @State private var weight = 1.0
    @State private var price = 250.0
    @State private var name = ""
    @State private var phone = ""
    @State private var address = ""
    @State private var dropOff = Date()
    @State private var pickup = Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date()
    @State private var notes = ""

    var available: [Dumpster] { store.dumpsters.filter { $0.status == .available } }
    var enabledPackages: [RentalPackage] { store.packages.filter(\.enabled) }

    var body: some View {
        Form {
            Section("container_information") {
                Picker("physical_dumpster", selection: $dumpsterID) {
                    Text("select_dumpster").tag(UUID?.none)
                    ForEach(available) { d in Text("\(d.number) · \(d.physicalSize) \(L10n.string("yards"))").tag(Optional(d.id)) }
                }
                Picker("rental_package", selection: $packageID) {
                    Text("custom_package").tag(UUID?.none)
                    ForEach(enabledPackages) { p in Text("\(p.name) · \(p.price.formatted(.currency(code: "USD")))").tag(Optional(p.id)) }
                }
                .onChange(of: packageID) { _, newValue in applyPackage(newValue) }
                IntegerInputField(title: "rented_as", value: $rentedAs, suffix: L10n.string("yards"), range: 1...60)
                IntegerInputField(title: "fill_limit", value: $fillLimit, suffix: L10n.string("yards"), range: 1...60)
                DecimalInputField(title: "weight_included", value: $weight, suffix: L10n.string("tons"), range: 0...20, decimalPlaces: 2)
                DecimalInputField(title: "price", value: $price, prefix: "$", range: 0...100000, decimalPlaces: 2)
            }
            Section("customer_information") {
                Picker("saved_customer", selection: $customerID) {
                    Text("new_or_manual_customer").tag(UUID?.none)
                    ForEach(store.customers.sorted { $0.name < $1.name }) { c in Text(c.name).tag(Optional(c.id)) }
                }
                .onChange(of: customerID) { _, newValue in applyCustomer(newValue) }
                TextField("name", text: $name)
                TextField("phone", text: $phone).keyboardType(.phonePad)
                TextField("address", text: $address)
            }
            Section("dates") {
                DatePicker("dropoff_date", selection: $dropOff, displayedComponents: .date)
                DatePicker("pickup_date", selection: $pickup, displayedComponents: .date)
            }
            Section("notes") { TextField("notes", text: $notes, axis: .vertical) }
        }
        .navigationTitle("new_rental_title")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("cancel") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("save") { save() }.disabled(dumpsterID == nil || name.trimmingCharacters(in: .whitespaces).isEmpty) }
        }
    }

    private func applyPackage(_ id: UUID?) {
        guard let id, let package = store.packages.first(where: { $0.id == id }) else { return }
        rentedAs = package.rentedAs
        fillLimit = package.fillLimit
        weight = package.weightAllowanceTons
        price = package.price
    }

    private func applyCustomer(_ id: UUID?) {
        guard let id, let customer = store.customers.first(where: { $0.id == id }) else { return }
        name = customer.name
        phone = customer.phone
        address = customer.address
    }

    private func save() {
        guard let id = dumpsterID, var dumpster = store.dumpsters.first(where: { $0.id == id }) else { return }
        dumpster.rentedAs = rentedAs
        dumpster.fillLimit = fillLimit
        dumpster.weightAllowanceTons = weight
        dumpster.price = price
        dumpster.customerName = name
        dumpster.phone = phone
        dumpster.address = address
        dumpster.dropOffDate = dropOff
        dumpster.pickupDate = pickup
        dumpster.notes = notes
        dumpster.status = Calendar.current.isDateInToday(pickup) ? .pickupToday : (pickup < Calendar.current.startOfDay(for: Date()) ? .overdue : .rented)
        store.update(dumpster)

        if customerID == nil && !store.customers.contains(where: { $0.name.caseInsensitiveCompare(name) == .orderedSame && $0.phone == phone }) {
            store.addCustomer(Customer(name: name, phone: phone, address: address))
        }
        dismiss()
    }
}
