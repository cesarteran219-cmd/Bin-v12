import Foundation
import UserNotifications

final class DumpsterStore: ObservableObject {
    @Published var dumpsters: [Dumpster] = [] { didSet { saveDumpsters(); PickupNotificationManager.shared.sync(dumpsters) } }
    @Published var customers: [Customer] = [] { didSet { saveCustomers() } }
    @Published var packages: [RentalPackage] = [] { didSet { savePackages() } }
    @Published var disposalSites: [DisposalSite] = [] { didSet { saveDisposalSites() } }

    private let dumpsterKey = "ctl_dumpsters_v1"
    private let customerKey = "ctl_customers_v2"
    private let packageKey = "ctl_packages_v2"
    private let disposalSiteKey = "ctl_disposal_sites_v1"

    init() {
        if !loadDumpsters() { seedDumpsters() }
        if !loadCustomers() { seedCustomersFromRentals() }
        if !loadPackages() { seedPackages() }
        _ = loadDisposalSites()
        refreshStatuses()
    }

    var availableCount: Int { dumpsters.filter { $0.status == .available }.count }
    var rentedCount: Int { dumpsters.filter { $0.status == .rented }.count }
    var pickupTodayCount: Int { dumpsters.filter { $0.status == .pickupToday }.count }
    var overdueCount: Int { dumpsters.filter { $0.status == .overdue }.count }

    func add(_ dumpster: Dumpster) { dumpsters.insert(dumpster, at: 0) }
    func deleteDumpster(_ dumpster: Dumpster) { dumpsters.removeAll { $0.id == dumpster.id } }

    func update(_ dumpster: Dumpster) {
        guard let i = dumpsters.firstIndex(where: { $0.id == dumpster.id }) else { return }
        dumpsters[i] = dumpster
    }

    func addCustomer(_ customer: Customer) { customers.insert(customer, at: 0) }
    func updateCustomer(_ customer: Customer) {
        guard let i = customers.firstIndex(where: { $0.id == customer.id }) else { return }
        customers[i] = customer
    }
    func deleteCustomer(_ customer: Customer) { customers.removeAll { $0.id == customer.id } }

    func addPackage(_ package: RentalPackage) { packages.append(package) }
    func updatePackage(_ package: RentalPackage) {
        guard let i = packages.firstIndex(where: { $0.id == package.id }) else { return }
        packages[i] = package
    }
    func deletePackage(_ package: RentalPackage) { packages.removeAll { $0.id == package.id } }

    func addDisposalSite(_ site: DisposalSite) { disposalSites.append(site) }
    func updateDisposalSite(_ site: DisposalSite) {
        guard let i = disposalSites.firstIndex(where: { $0.id == site.id }) else { return }
        disposalSites[i] = site
    }
    func deleteDisposalSite(_ site: DisposalSite) { disposalSites.removeAll { $0.id == site.id } }

    func markPickedUp(_ dumpster: Dumpster) {
        guard let i = dumpsters.firstIndex(where: { $0.id == dumpster.id }) else { return }
        dumpsters[i].status = .available
        dumpsters[i].rentedAs = nil
        dumpsters[i].fillLimit = nil
        dumpsters[i].weightAllowanceTons = nil
        dumpsters[i].price = nil
        dumpsters[i].customerName = nil
        dumpsters[i].phone = nil
        dumpsters[i].address = nil
        dumpsters[i].dropOffDate = nil
        dumpsters[i].pickupDate = nil
        dumpsters[i].notes = nil
    }

    func refreshStatuses() {
        let cal = Calendar.current
        for index in dumpsters.indices where dumpsters[index].status != .available {
            guard let pickup = dumpsters[index].pickupDate else { continue }
            if cal.isDateInToday(pickup) {
                dumpsters[index].status = .pickupToday
            } else if pickup < cal.startOfDay(for: Date()) {
                dumpsters[index].status = .overdue
            } else {
                dumpsters[index].status = .rented
            }
        }
    }

    private func seedDumpsters() {
        let cal = Calendar.current
        let today = Date()
        dumpsters = [
            Dumpster(number: "#10-01", physicalSize: 10, status: .available),
            Dumpster(number: "#10-02", physicalSize: 10, status: .available),
            Dumpster(number: "#15-03", physicalSize: 15, rentedAs: 10, fillLimit: 10, weightAllowanceTons: 1, price: 250, customerName: "Juan Pérez", phone: "(720) 555-1234", address: "123 Main St, Denver, CO", dropOffDate: today, pickupDate: cal.date(byAdding: .day, value: 6, to: today), notes: "Remodelación de cocina", status: .rented),
            Dumpster(number: "#15-04", physicalSize: 15, status: .available),
            Dumpster(number: "#20-01", physicalSize: 20, rentedAs: 15, fillLimit: 15, weightAllowanceTons: 2, price: 300, customerName: "María López", phone: "(720) 555-9876", address: "456 Elm St, Aurora, CO", dropOffDate: cal.date(byAdding: .day, value: -5, to: today), pickupDate: today, notes: "Limpieza de garaje", status: .pickupToday)
        ]
    }

    private func seedCustomersFromRentals() {
        var seen = Set<String>()
        customers = dumpsters.compactMap { d in
            guard let name = d.customerName, !name.isEmpty, !seen.contains(name.lowercased()) else { return nil }
            seen.insert(name.lowercased())
            return Customer(name: name, phone: d.phone ?? "", address: d.address ?? "")
        }
    }

    private func seedPackages() {
        packages = [
            RentalPackage(name: "10 yd", rentedAs: 10, fillLimit: 10, weightAllowanceTons: 1, price: 250),
            RentalPackage(name: "15 yd", rentedAs: 15, fillLimit: 15, weightAllowanceTons: 2, price: 300),
            RentalPackage(name: "20 yd", rentedAs: 20, fillLimit: 20, weightAllowanceTons: 3, price: 350),
            RentalPackage(name: "25 yd", rentedAs: 25, fillLimit: 25, weightAllowanceTons: 3.5, price: 400),
            RentalPackage(name: "30 yd", rentedAs: 30, fillLimit: 30, weightAllowanceTons: 4, price: 450)
        ]
    }

    private func saveDumpsters() { save(dumpsters, key: dumpsterKey) }
    private func saveCustomers() { save(customers, key: customerKey) }
    private func savePackages() { save(packages, key: packageKey) }
    private func saveDisposalSites() { save(disposalSites, key: disposalSiteKey) }

    private func save<T: Encodable>(_ value: T, key: String) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    private func loadDumpsters() -> Bool { load([Dumpster].self, key: dumpsterKey).map { dumpsters = $0 } != nil }
    private func loadCustomers() -> Bool { load([Customer].self, key: customerKey).map { customers = $0 } != nil }
    private func loadPackages() -> Bool { load([RentalPackage].self, key: packageKey).map { packages = $0 } != nil }
    private func loadDisposalSites() -> Bool { load([DisposalSite].self, key: disposalSiteKey).map { disposalSites = $0 } != nil }

    private func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }
}


final class PickupNotificationManager {
    static let shared = PickupNotificationManager()
    private let center = UNUserNotificationCenter.current()
    private let enabledKey = "pickupNotificationsEnabled"
    private let identifierPrefix = "ctl-pickup-"

    private init() {}

    var isEnabled: Bool { UserDefaults.standard.bool(forKey: enabledKey) }

    func setEnabled(_ enabled: Bool, dumpsters: [Dumpster]) async -> Bool {
        if !enabled {
            UserDefaults.standard.set(false, forKey: enabledKey)
            removePickupNotifications()
            return false
        }

        do {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            UserDefaults.standard.set(granted, forKey: enabledKey)
            if granted { sync(dumpsters) }
            return granted
        } catch {
            UserDefaults.standard.set(false, forKey: enabledKey)
            return false
        }
    }

    func sync(_ dumpsters: [Dumpster]) {
        guard isEnabled else { return }
        center.getNotificationSettings { [weak self] settings in
            guard let self, settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else { return }
            self.removePickupNotifications { [weak self] in
                guard let self else { return }
                for dumpster in dumpsters where dumpster.status != .available {
                    self.schedulePickupNotifications(for: dumpster)
                }
            }
        }
    }

    private func removePickupNotifications(completion: (() -> Void)? = nil) {
        center.getPendingNotificationRequests { [weak self] requests in
            guard let self else { completion?(); return }
            let ids = requests.map(\.identifier).filter { $0.hasPrefix(self.identifierPrefix) }
            if !ids.isEmpty { self.center.removePendingNotificationRequests(withIdentifiers: ids) }
            completion?()
        }
    }

    private func schedulePickupNotifications(for dumpster: Dumpster) {
        guard let pickupDate = dumpster.pickupDate else { return }
        let calendar = Calendar.current
        let customer = nonEmpty(dumpster.customerName) ?? L10n.string("no_customer")
        let address = nonEmpty(dumpster.address) ?? L10n.string("address_not_available")

        if let dayBefore = calendar.date(byAdding: .day, value: -1, to: pickupDate) {
            schedule(
                identifier: "\(identifierPrefix)\(dumpster.id.uuidString)-before",
                date: setTime(dayBefore, hour: 18, minute: 0),
                title: L10n.string("pickup_reminder_tomorrow"),
                body: "\(dumpster.number) · \(customer) · \(address)"
            )
        }

        schedule(
            identifier: "\(identifierPrefix)\(dumpster.id.uuidString)-today",
            date: setTime(pickupDate, hour: 8, minute: 0),
            title: L10n.string("pickup_reminder_today"),
            body: "\(dumpster.number) · \(customer) · \(address)"
        )
    }

    private func schedule(identifier: String, date: Date, title: String, body: String) {
        guard date > Date() else { return }
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        center.add(UNNotificationRequest(identifier: identifier, content: content, trigger: trigger))
    }

    private func setTime(_ date: Date, hour: Int, minute: Int) -> Date {
        Calendar.current.date(bySettingHour: hour, minute: minute, second: 0, of: date) ?? date
    }

    private func nonEmpty(_ value: String?) -> String? {
        guard let value else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed.caseInsensitiveCompare("N/A") != .orderedSame else { return nil }
        return trimmed
    }
}
