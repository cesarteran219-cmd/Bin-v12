import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var store: DumpsterStore
    @AppStorage("appLanguage") private var appLanguage = "es"
    @AppStorage("pickupNotificationsEnabled") private var pickupNotificationsEnabled = false
    @State private var notificationMessage: String?

    var body: some View {
        Form {
            Section("language") {
                Picker("language", selection: $appLanguage) {
                    Text("Español 🇲🇽").tag("es")
                    Text("English 🇺🇸").tag("en")
                }.pickerStyle(.inline)
            }
            Section("your_business") {
                Label("CTL Roll Offs", systemImage: "building.2.fill")
                NavigationLink { PackageManagerView() } label: { Label("pricing_sizes", systemImage: "dollarsign.circle.fill") }
                NavigationLink { DumpsterListView() } label: { Label("manage_dumpsters", systemImage: "shippingbox.fill") }
                NavigationLink { CustomersView() } label: { Label("manage_customers", systemImage: "person.2.fill") }
                NavigationLink { DisposalSiteManagerView() } label: { Label("route_dump_sites", systemImage: "trash.fill") }
            }
            Section("notifications") {
                Toggle("pickup_notifications", isOn: Binding(
                    get: { pickupNotificationsEnabled },
                    set: { newValue in
                        Task {
                            let enabled = await PickupNotificationManager.shared.setEnabled(newValue, dumpsters: store.dumpsters)
                            await MainActor.run {
                                pickupNotificationsEnabled = enabled
                                notificationMessage = enabled ? L10n.string("pickup_notifications_on") : (newValue ? L10n.string("pickup_notifications_denied") : L10n.string("pickup_notifications_off"))
                            }
                        }
                    }
                ))
                if let notificationMessage { Text(notificationMessage).font(.footnote).foregroundStyle(.secondary) }
                Text("pickup_notifications_detail").font(.footnote).foregroundStyle(.secondary)
            }
            Section("about") { Text("Version 3.4") }
        }
        .navigationTitle("settings_title")
    }
}

struct PackageManagerView: View {
    @EnvironmentObject var store: DumpsterStore
    @State private var showingAdd = false

    var body: some View {
        List {
            ForEach(store.packages) { package in
                NavigationLink { PackageEditorView(package: package) } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(package.name).font(.headline)
                            Text("\(package.rentedAs) \(L10n.string("yards")) · \(package.weightAllowanceTons.formatted()) \(L10n.string("tons")) · \(package.price.formatted(.currency(code: "USD")))")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: package.enabled ? "checkmark.circle.fill" : "pause.circle").foregroundStyle(package.enabled ? Color.green : Color.secondary)
                    }
                }
            }
            .onDelete { offsets in
                for index in offsets { store.deletePackage(store.packages[index]) }
            }
        }
        .navigationTitle("pricing_sizes")
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showingAdd = true } label: { Image(systemName: "plus") } } }
        .sheet(isPresented: $showingAdd) { NavigationStack { PackageEditorView(package: nil) } }
    }
}

struct PackageEditorView: View {
    @EnvironmentObject var store: DumpsterStore
    @Environment(\.dismiss) private var dismiss
    let package: RentalPackage?

    @State private var name: String
    @State private var rentedAs: Int
    @State private var fillLimit: Int
    @State private var weight: Double
    @State private var price: Double
    @State private var enabled: Bool

    init(package: RentalPackage?) {
        self.package = package
        _name = State(initialValue: package?.name ?? "")
        _rentedAs = State(initialValue: package?.rentedAs ?? 10)
        _fillLimit = State(initialValue: package?.fillLimit ?? 10)
        _weight = State(initialValue: package?.weightAllowanceTons ?? 1)
        _price = State(initialValue: package?.price ?? 250)
        _enabled = State(initialValue: package?.enabled ?? true)
    }

    var body: some View {
        Form {
            Section("rental_package") {
                TextField("package_name", text: $name)
                IntegerInputField(title: "rented_as", value: $rentedAs, suffix: L10n.string("yards"), range: 1...60)
                IntegerInputField(title: "fill_limit", value: $fillLimit, suffix: L10n.string("yards"), range: 1...60)
                DecimalInputField(title: "weight_included", value: $weight, suffix: L10n.string("tons"), range: 0...20, decimalPlaces: 2)
                DecimalInputField(title: "price", value: $price, prefix: "$", range: 0...100000, decimalPlaces: 2)
                Toggle("package_enabled", isOn: $enabled)
            }
            if let package { Section { Button("delete_package", role: .destructive) { store.deletePackage(package); dismiss() } } }
        }
        .keyboardDoneToolbar()
        .navigationTitle(package == nil ? L10n.string("add_package") : L10n.string("edit_package"))
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("cancel") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("save") { save() }.disabled(name.trimmingCharacters(in: .whitespaces).isEmpty) }
        }
    }

    private func save() {
        if let package {
            var updated = package
            updated.name = name; updated.rentedAs = rentedAs; updated.fillLimit = fillLimit; updated.weightAllowanceTons = weight; updated.price = price; updated.enabled = enabled
            store.updatePackage(updated)
        } else {
            store.addPackage(RentalPackage(name: name, rentedAs: rentedAs, fillLimit: fillLimit, weightAllowanceTons: weight, price: price, enabled: enabled))
        }
        dismiss()
    }
}
