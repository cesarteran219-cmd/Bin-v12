import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            NavigationStack { DashboardView() }
                .tabItem { Label("tab_home", systemImage: "house.fill") }

            NavigationStack { DumpsterListView() }
                .tabItem { Label("tab_dumpsters", systemImage: "shippingbox.fill") }

            NavigationStack { DumpsterMapView() }
                .tabItem { Label("tab_map", systemImage: "map.fill") }

            NavigationStack { SmartImportView() }
                .tabItem { Label("tab_ai", systemImage: "sparkles") }

            NavigationStack { MoreHubView() }
                .tabItem { Label("tab_more", systemImage: "ellipsis") }
        }
        .tint(Color.ctlRed)
        .keyboardDoneToolbar()
    }
}

struct MoreHubView: View {
    var body: some View {
        List {
            Section {
                NavigationLink { DailyRouteView() } label: {
                    Label("route_title", systemImage: "point.topleft.down.to.point.bottomright.curvepath")
                }
                NavigationLink { RentalsView() } label: {
                    Label("tab_calendar", systemImage: "calendar")
                }
                NavigationLink { CustomersView() } label: {
                    Label("tab_customers", systemImage: "person.2.fill")
                }
                NavigationLink { SettingsView() } label: {
                    Label("settings_title", systemImage: "gearshape.fill")
                }
            }
        }
        .navigationTitle("tab_more")
        .ctlLogoToolbar()
    }
}
