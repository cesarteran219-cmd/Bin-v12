import SwiftUI

struct DumpsterListView: View {
    @EnvironmentObject var store: DumpsterStore
    @State private var search = ""
    @State private var showingAdd = false

    var filtered: [Dumpster] {
        guard !search.isEmpty else { return store.dumpsters }
        return store.dumpsters.filter { $0.number.localizedCaseInsensitiveContains(search) || ($0.customerName?.localizedCaseInsensitiveContains(search) ?? false) }
    }

    var body: some View {
        List {
            ForEach(filtered) { dumpster in
                NavigationLink(value: dumpster) {
                    HStack {
                        Image(systemName: "shippingbox.fill").foregroundStyle(Color.ctlRed).font(.title2)
                        VStack(alignment: .leading) {
                            Text(dumpster.number).font(.headline)
                            Text("\(dumpster.physicalSize) \(L10n.string("yards"))").foregroundStyle(.secondary)
                            if let rented = dumpster.rentedAs { Text("\(L10n.string("rented_as")): \(rented) \(L10n.string("yards"))").font(.caption).foregroundStyle(.secondary) }
                        }
                        Spacer()
                        StatusBadge(status: dumpster.status)
                    }.padding(.vertical, 5)
                }
            }
            .onDelete { offsets in
                let list = filtered
                for index in offsets { store.deleteDumpster(list[index]) }
            }
        }
        .scrollContentBackground(.hidden).background(Color.ctlBackground)
        .searchable(text: $search, prompt: "search_dumpster")
        .navigationTitle("dumpsters_title")
        .ctlLogoToolbar()
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) { Button { showingAdd = true } label: { Image(systemName: "plus") } }
        }
        .sheet(isPresented: $showingAdd) { NavigationStack { DumpsterEditorView(dumpster: nil) } }
        .navigationDestination(for: Dumpster.self) { DumpsterDetailView(dumpster: $0) }
    }
}
