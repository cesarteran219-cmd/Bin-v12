import Foundation

struct Customer: Identifiable, Hashable, Codable {
    let id: UUID
    var name: String
    var phone: String
    var address: String
    var notes: String

    init(id: UUID = UUID(), name: String, phone: String = "", address: String = "", notes: String = "") {
        self.id = id
        self.name = name
        self.phone = phone
        self.address = address
        self.notes = notes
    }
}

struct RentalPackage: Identifiable, Hashable, Codable {
    let id: UUID
    var name: String
    var rentedAs: Int
    var fillLimit: Int
    var weightAllowanceTons: Double
    var price: Double
    var enabled: Bool

    init(id: UUID = UUID(), name: String, rentedAs: Int, fillLimit: Int, weightAllowanceTons: Double, price: Double, enabled: Bool = true) {
        self.id = id
        self.name = name
        self.rentedAs = rentedAs
        self.fillLimit = fillLimit
        self.weightAllowanceTons = weightAllowanceTons
        self.price = price
        self.enabled = enabled
    }
}

struct Dumpster: Identifiable, Hashable, Codable {
    enum Status: String, CaseIterable, Codable {
        case available, rented, pickupToday, overdue

        var key: String {
            switch self {
            case .available: return "status_available"
            case .rented: return "status_rented"
            case .pickupToday: return "status_pickup_today"
            case .overdue: return "status_overdue"
            }
        }
    }

    let id: UUID
    var number: String
    var physicalSize: Int
    var rentedAs: Int?
    var fillLimit: Int?
    var weightAllowanceTons: Double?
    var price: Double?
    var customerName: String?
    var phone: String?
    var address: String?
    var dropOffDate: Date?
    var pickupDate: Date?
    var notes: String?
    var status: Status
    var photos: [BinPhotoRecord]


    enum CodingKeys: String, CodingKey {
        case id, number, physicalSize, rentedAs, fillLimit, weightAllowanceTons, price, customerName, phone, address, dropOffDate, pickupDate, notes, status, photos
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(UUID.self, forKey: .id)
        number = try c.decode(String.self, forKey: .number)
        physicalSize = try c.decode(Int.self, forKey: .physicalSize)
        rentedAs = try c.decodeIfPresent(Int.self, forKey: .rentedAs)
        fillLimit = try c.decodeIfPresent(Int.self, forKey: .fillLimit)
        weightAllowanceTons = try c.decodeIfPresent(Double.self, forKey: .weightAllowanceTons)
        price = try c.decodeIfPresent(Double.self, forKey: .price)
        customerName = try c.decodeIfPresent(String.self, forKey: .customerName)
        phone = try c.decodeIfPresent(String.self, forKey: .phone)
        address = try c.decodeIfPresent(String.self, forKey: .address)
        dropOffDate = try c.decodeIfPresent(Date.self, forKey: .dropOffDate)
        pickupDate = try c.decodeIfPresent(Date.self, forKey: .pickupDate)
        notes = try c.decodeIfPresent(String.self, forKey: .notes)
        status = try c.decode(Dumpster.Status.self, forKey: .status)
        photos = try c.decodeIfPresent([BinPhotoRecord].self, forKey: .photos) ?? []
    }

    init(id: UUID = UUID(), number: String, physicalSize: Int, rentedAs: Int? = nil, fillLimit: Int? = nil, weightAllowanceTons: Double? = nil, price: Double? = nil, customerName: String? = nil, phone: String? = nil, address: String? = nil, dropOffDate: Date? = nil, pickupDate: Date? = nil, notes: String? = nil, status: Status = .available) {
        self.id = id
        self.number = number
        self.physicalSize = physicalSize
        self.rentedAs = rentedAs
        self.fillLimit = fillLimit
        self.weightAllowanceTons = weightAllowanceTons
        self.price = price
        self.customerName = customerName
        self.phone = phone
        self.address = address
        self.dropOffDate = dropOffDate
        self.pickupDate = pickupDate
        self.notes = notes
        self.status = status
        self.photos = []
    }
}
