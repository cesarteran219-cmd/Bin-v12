import SwiftUI

struct RentalsView: View {
    @EnvironmentObject var store: DumpsterStore
    var body: some View {
        List(store.dumpsters.filter { $0.status != .available }.sorted { ($0.pickupDate ?? .distantFuture) < ($1.pickupDate ?? .distantFuture) }) { d in
            NavigationLink(value: d) {
                VStack(alignment: .leading, spacing: 5) {
                    HStack { Text(d.number).font(.headline); Spacer(); StatusBadge(status: d.status) }
                    Text(d.customerName ?? "")
                    if let date = d.pickupDate { Label(date.formatted(date: .abbreviated, time: .omitted), systemImage: "calendar") .font(.caption).foregroundStyle(.secondary) }
                }.padding(.vertical, 4)
            }
        }
        .scrollContentBackground(.hidden).background(Color.ctlBackground)
        .navigationTitle("calendar_title")
        .navigationDestination(for: Dumpster.self) { DumpsterDetailView(dumpster: $0) }
    }
}
