import SwiftUI

struct CustomersView: View {
    @EnvironmentObject var store: DumpsterStore
    @State private var showingNew = false

    var body: some View {
        List {
            if store.customers.isEmpty {
                ContentUnavailableView("no_customers", systemImage: "person.2")
            }
            ForEach(store.customers.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }) { customer in
                NavigationLink {
                    CustomerEditorView(customer: customer)
                } label: {
                    HStack {
                        Image(systemName: "person.crop.circle.fill").font(.largeTitle).foregroundStyle(.secondary)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(customer.name).font(.headline)
                            if !customer.phone.isEmpty { Text(customer.phone).font(.caption).foregroundStyle(.secondary) }
                            if !customer.address.isEmpty { Text(customer.address).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                        }
                    }.padding(.vertical, 4)
                }
            }
            .onDelete { offsets in
                let sorted = store.customers.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
                for index in offsets { store.deleteCustomer(sorted[index]) }
            }
        }
        .scrollContentBackground(.hidden).background(Color.ctlBackground)
        .navigationTitle("customers_title")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showingNew = true } label: { Image(systemName: "person.badge.plus") }
            }
        }
        .sheet(isPresented: $showingNew) { NavigationStack { CustomerEditorView(customer: nil) } }
    }
}

struct CustomerEditorView: View {
    @EnvironmentObject var store: DumpsterStore
    @Environment(\.dismiss) private var dismiss
    let customer: Customer?

    @State private var name: String
    @State private var phone: String
    @State private var address: String
    @State private var notes: String

    init(customer: Customer?) {
        self.customer = customer
        _name = State(initialValue: customer?.name ?? "")
        _phone = State(initialValue: customer?.phone ?? "")
        _address = State(initialValue: customer?.address ?? "")
        _notes = State(initialValue: customer?.notes ?? "")
    }

    var body: some View {
        Form {
            Section("customer_information") {
                TextField("name", text: $name)
                TextField("phone", text: $phone).keyboardType(.phonePad)
                TextField("address", text: $address)
                TextField("notes", text: $notes, axis: .vertical)
            }
            if let customer {
                Section {
                    Button("delete_customer", role: .destructive) {
                        store.deleteCustomer(customer)
                        dismiss()
                    }
                }
            }
        }
        .navigationTitle(customer == nil ? L10n.string("add_customer") : L10n.string("edit_customer"))
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("cancel") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("save") { save() }.disabled(name.trimmingCharacters(in: .whitespaces).isEmpty) }
        }
    }

    private func save() {
        if let customer {
            var updated = customer
            updated.name = name
            updated.phone = phone
            updated.address = address
            updated.notes = notes
            store.updateCustomer(updated)
        } else {
            store.addCustomer(Customer(name: name, phone: phone, address: address, notes: notes))
        }
        dismiss()
    }
}
