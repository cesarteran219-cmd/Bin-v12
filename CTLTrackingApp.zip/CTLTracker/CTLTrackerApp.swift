import SwiftUI

@main
struct CTLTrackerApp: App {
    @StateObject private var store = DumpsterStore()
    @AppStorage("appLanguage") private var appLanguage = "es"

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environment(\.locale, Locale(identifier: appLanguage))
                .preferredColorScheme(.dark)
        }
    }
}
