import SwiftUI
import MapKit

struct DumpsterDetailView: View {
    @EnvironmentObject var store: DumpsterStore
    let dumpster: Dumpster
    @State private var editing = false
    @State private var showingCamera = false
    @StateObject private var locationProvider = CurrentLocationProvider()

    var current: Dumpster { store.dumpsters.first(where: { $0.id == dumpster.id }) ?? dumpster }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                ZStack {
                    RoundedRectangle(cornerRadius: 18).fill(Color.ctlCard).frame(height: 180)
                    VStack(spacing: 10) {
                        Image(systemName: "shippingbox.fill").font(.system(size: 72)).foregroundStyle(Color.ctlRed)
                        Text(current.number).font(.title.bold())
                    }
                }
                DetailLine("status", value: L10n.string(current.status.key))
                DetailLine("physical_size", value: "\(current.physicalSize) \(L10n.string("yards"))")
                if let v = current.rentedAs { DetailLine("rented_as", value: "\(v) \(L10n.string("yards"))") }
                if let v = current.fillLimit { DetailLine("fill_limit", value: "\(v) \(L10n.string("yards"))") }
                if let v = current.weightAllowanceTons { DetailLine("weight_included", value: "\(v.formatted()) \(L10n.string("tons"))") }
                if let v = current.price { DetailLine("price", value: v.formatted(.currency(code: "USD"))) }
                if let v = current.customerName { DetailLine("customer", value: v) }
                if let v = current.phone { DetailLine("phone", value: v) }
                if let v = current.address { DetailLine("address", value: v) }
                if let v = current.dropOffDate { DetailLine("dropoff_date", value: v.formatted(date: .abbreviated, time: .omitted)) }
                if let v = current.pickupDate { DetailLine("pickup_date", value: v.formatted(date: .abbreviated, time: .omitted)) }
                if let v = current.notes, !v.isEmpty { DetailLine("notes", value: v) }

                if current.status != .available, let address = current.address, !address.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, address.caseInsensitiveCompare("N/A") != .orderedSame {
                    VStack(spacing: 10) {
                        Button { openDirections(address: address) } label: {
                            Label("dropoff_directions", systemImage: "map.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(Color.ctlRed)

                        Button { openDirections(address: address) } label: {
                            Label("pickup_directions", systemImage: "arrow.triangle.turn.up.right.diamond.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)
                    }
                }

                binPhotosSection

                if current.status != .available {
                    Button("mark_picked_up") { store.markPickedUp(current) }
                        .font(.headline).frame(maxWidth: .infinity).padding()
                        .buttonStyle(.borderedProminent).tint(Color.ctlRed)
                }
            }.padding()
        }
        .background(Color.ctlBackground)
        .navigationTitle(current.number)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("edit") { editing = true } } }
        .sheet(isPresented: $editing) { NavigationStack { DumpsterEditorView(dumpster: current) } }
        .sheet(isPresented: $showingCamera) {
            CameraPicker { image in
                savePhoto(image)
            }
            .ignoresSafeArea()
        }
        .onAppear { locationProvider.request() }
    }

    @ViewBuilder
    private var binPhotosSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("bin_photos", systemImage: "camera.fill")
                    .font(.headline)
                Spacer()
                Button {
                    locationProvider.request()
                    showingCamera = true
                } label: {
                    Label("take_bin_photo", systemImage: "camera")
                }
                .buttonStyle(.borderedProminent)
                .tint(Color.ctlRed)
            }

            if current.photos.isEmpty {
                Text("bin_photos_empty")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(current.photos.sorted(by: { $0.capturedAt > $1.capturedAt })) { photo in
                    BinPhotoCard(photo: photo, dumpster: current) { deletePhoto(photo) }
                }
            }
        }
        .padding()
        .background(Color.ctlCard)
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func savePhoto(_ image: UIImage) {
        guard let fileName = BinPhotoStorage.save(image) else { return }
        var updated = current
        let location = locationProvider.location
        let address = current.address?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        updated.photos.append(BinPhotoRecord(
            fileName: fileName,
            capturedAt: Date(),
            address: address,
            latitude: location?.coordinate.latitude,
            longitude: location?.coordinate.longitude
        ))
        store.update(updated)
    }

    private func deletePhoto(_ photo: BinPhotoRecord) {
        var updated = current
        updated.photos.removeAll { $0.id == photo.id }
        BinPhotoStorage.delete(photo.fileName)
        store.update(updated)
    }

    private func openDirections(address: String) {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = address
        MKLocalSearch(request: request).start { response, _ in
            guard let item = response?.mapItems.first else { return }
            item.name = current.customerName ?? current.number
            item.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving])
        }
    }
}

private struct BinPhotoCard: View {
    let photo: BinPhotoRecord
    let dumpster: Dumpster
    let onDelete: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let image = BinPhotoStorage.load(photo.fileName) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 190)
                    .clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            Label(photo.capturedAt.formatted(date: .abbreviated, time: .shortened), systemImage: "clock.fill")
                .font(.subheadline.bold())
            if !photo.address.isEmpty {
                Label(photo.address, systemImage: "mappin.and.ellipse")
                    .font(.subheadline)
            }
            if let lat = photo.latitude, let lon = photo.longitude {
                Label(String(format: "%.5f, %.5f", lat, lon), systemImage: "location.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                Label("location_not_available", systemImage: "location.slash")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            if let drop = dumpster.dropOffDate {
                Label("\(L10n.string("dropoff_time")): \(drop.formatted(date: .abbreviated, time: .shortened))", systemImage: "truck.box.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            HStack {
                if let lat = photo.latitude, let lon = photo.longitude {
                    Button("open_photo_location") {
                        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
                        let item = MKMapItem(placemark: MKPlacemark(coordinate: coordinate))
                        item.name = dumpster.number
                        item.openInMaps()
                    }
                    .buttonStyle(.bordered)
                }
                Spacer()
                Button(role: .destructive, action: onDelete) {
                    Image(systemName: "trash")
                }
                .buttonStyle(.bordered)
            }
        }
        .padding(10)
        .background(Color.secondary.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct DumpsterEditorView: View {
    @EnvironmentObject var store: DumpsterStore
    @Environment(\.dismiss) private var dismiss
    let dumpster: Dumpster?

    @State private var number: String
    @State private var physicalSize: Int
    @State private var status: Dumpster.Status
    @State private var rentedAs: Int
    @State private var fillLimit: Int
    @State private var weight: Double
    @State private var price: Double
    @State private var customerName: String
    @State private var phone: String
    @State private var address: String
    @State private var dropOff: Date
    @State private var pickup: Date
    @State private var notes: String

    init(dumpster: Dumpster?) {
        self.dumpster = dumpster
        _number = State(initialValue: dumpster?.number ?? "#")
        _physicalSize = State(initialValue: dumpster?.physicalSize ?? 15)
        _status = State(initialValue: dumpster?.status ?? .available)
        _rentedAs = State(initialValue: dumpster?.rentedAs ?? 10)
        _fillLimit = State(initialValue: dumpster?.fillLimit ?? 10)
        _weight = State(initialValue: dumpster?.weightAllowanceTons ?? 1)
        _price = State(initialValue: dumpster?.price ?? 250)
        _customerName = State(initialValue: dumpster?.customerName ?? "")
        _phone = State(initialValue: dumpster?.phone ?? "")
        _address = State(initialValue: dumpster?.address ?? "")
        _dropOff = State(initialValue: dumpster?.dropOffDate ?? Date())
        _pickup = State(initialValue: dumpster?.pickupDate ?? Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date())
        _notes = State(initialValue: dumpster?.notes ?? "")
    }

    var body: some View {
        Form {
            Section("container_information") {
                TextField("dumpster_number", text: $number)
                IntegerInputField(title: "physical_size", value: $physicalSize, suffix: L10n.string("yards"), range: 1...60)
                Picker("status", selection: $status) {
                    ForEach(Dumpster.Status.allCases, id: \.self) { Text(LocalizedStringKey($0.key)).tag($0) }
                }
            }
            if status != .available {
                Section("rental_information") {
                    IntegerInputField(title: "rented_as", value: $rentedAs, suffix: L10n.string("yards"), range: 1...60)
                    IntegerInputField(title: "fill_limit", value: $fillLimit, suffix: L10n.string("yards"), range: 1...60)
                    DecimalInputField(title: "weight_included", value: $weight, suffix: L10n.string("tons"), range: 0...20, decimalPlaces: 2)
                    DecimalInputField(title: "price", value: $price, prefix: "$", range: 0...100000, decimalPlaces: 2)
                    TextField("name", text: $customerName)
                    TextField("phone", text: $phone).keyboardType(.phonePad)
                    TextField("address", text: $address)
                    DatePicker("dropoff_date", selection: $dropOff, displayedComponents: .date)
                    DatePicker("pickup_date", selection: $pickup, displayedComponents: .date)
                    TextField("notes", text: $notes, axis: .vertical)
                }
            }
            if let dumpster {
                Section { Button("delete_dumpster", role: .destructive) { store.deleteDumpster(dumpster); dismiss() } }
            }
        }
        .keyboardDoneToolbar()
        .navigationTitle(dumpster == nil ? L10n.string("add_dumpster") : L10n.string("edit_dumpster"))
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("cancel") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("save") { save() }.disabled(number.trimmingCharacters(in: .whitespaces).isEmpty) }
        }
    }

    private func save() {
        var updated = dumpster ?? Dumpster(number: number, physicalSize: physicalSize)
        updated.number = number
        updated.physicalSize = physicalSize
        updated.status = status
        if status == .available {
            updated.rentedAs = nil; updated.fillLimit = nil; updated.weightAllowanceTons = nil; updated.price = nil
            updated.customerName = nil; updated.phone = nil; updated.address = nil; updated.dropOffDate = nil; updated.pickupDate = nil; updated.notes = nil
        } else {
            updated.rentedAs = rentedAs; updated.fillLimit = fillLimit; updated.weightAllowanceTons = weight; updated.price = price
            updated.customerName = customerName; updated.phone = phone; updated.address = address; updated.dropOffDate = dropOff; updated.pickupDate = pickup; updated.notes = notes
        }
        if dumpster == nil { store.add(updated) } else { store.update(updated) }
        dismiss()
    }
}

private struct DetailLine: View {
    let title: LocalizedStringKey
    let value: String
    init(_ title: LocalizedStringKey, value: String) { self.title = title; self.value = value }
    var body: some View {
        HStack(alignment: .top) {
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).multilineTextAlignment(.trailing).fontWeight(.semibold)
        }
        .padding().background(Color.ctlCard).clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
