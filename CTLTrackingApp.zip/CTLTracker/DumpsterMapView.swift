import SwiftUI
import MapKit
import CoreLocation

struct DumpsterMapView: View {
    @EnvironmentObject var store: DumpsterStore
    @State private var locations: [DumpsterMapLocation] = []
    @State private var isLoading = false
    @State private var cameraPosition: MapCameraPosition = .automatic

    private var activeDumpsters: [Dumpster] {
        store.dumpsters.filter { dumpster in
            let address = (dumpster.address ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            return dumpster.status != .available && !address.isEmpty && address.caseInsensitiveCompare("N/A") != .orderedSame
        }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            Map(position: $cameraPosition) {
                ForEach(locations) { item in
                    Marker(item.dumpster.number, coordinate: item.coordinate)
                        .tint(markerColor(item.dumpster.status))
                }
            }
            .mapControls {
                MapCompass()
                MapScaleView()
            }

            if activeDumpsters.isEmpty {
                ContentUnavailableView(
                    L10n.string("map_empty_title"),
                    systemImage: "map",
                    description: Text("map_empty_message")
                )
            } else if isLoading && locations.isEmpty {
                ProgressView("map_loading")
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                    .padding()
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(locations) { item in
                            VStack(alignment: .leading, spacing: 8) {
                                Button {
                                    cameraPosition = .region(MKCoordinateRegion(
                                        center: item.coordinate,
                                        span: MKCoordinateSpan(latitudeDelta: 0.04, longitudeDelta: 0.04)
                                    ))
                                } label: {
                                    VStack(alignment: .leading, spacing: 4) {
                                    HStack {
                                        Text(item.dumpster.number).font(.headline)
                                        Spacer(minLength: 8)
                                        Text(LocalizedStringKey(item.dumpster.status.key))
                                            .font(.caption.bold())
                                            .foregroundStyle(markerColor(item.dumpster.status))
                                    }
                                    if let customer = item.dumpster.customerName {
                                        Text(customer).font(.subheadline)
                                    }
                                    Text(item.dumpster.address ?? "")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(2)
                                    if let rented = item.dumpster.rentedAs {
                                        Text("\(L10n.string("rented_as")): \(rented) \(L10n.string("yards"))")
                                            .font(.caption2)
                                            .foregroundStyle(.secondary)
                                    }
                                }
                                }
                                .buttonStyle(.plain)

                                Button { openInMaps(item) } label: {
                                    Label("open_apple_maps", systemImage: "map.fill")
                                        .font(.caption.bold())
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(Color.ctlRed)
                            }
                            .frame(width: 240, alignment: .leading)
                            .padding(12)
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                        }
                    }
                    .padding()
                }
            }
        }
        .navigationTitle("map_title")
        .ctlLogoToolbar()
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    Task { await loadLocations(force: true) }
                } label: { Image(systemName: "arrow.clockwise") }
                .disabled(isLoading)
            }
        }
        .task { await loadLocations(force: false) }
        .onChange(of: store.dumpsters) { _, _ in
            Task { await loadLocations(force: true) }
        }
    }

    @MainActor
    private func loadLocations(force: Bool) async {
        if isLoading { return }
        if !force && !locations.isEmpty { return }
        isLoading = true
        defer { isLoading = false }

        var newLocations: [DumpsterMapLocation] = []
        let geocoder = CLGeocoder()

        for dumpster in activeDumpsters {
            guard let address = dumpster.address else { continue }
            do {
                let placemarks = try await geocoder.geocodeAddressString(address)
                if let coordinate = placemarks.first?.location?.coordinate {
                    newLocations.append(DumpsterMapLocation(dumpster: dumpster, coordinate: coordinate))
                }
            } catch {
                // Skip addresses that cannot be geocoded. They remain editable in the rental.
            }
        }
        locations = newLocations
        if !newLocations.isEmpty { cameraPosition = .automatic }
    }

    private func openInMaps(_ item: DumpsterMapLocation) {
        let placemark = MKPlacemark(coordinate: item.coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = item.dumpster.customerName ?? item.dumpster.number
        mapItem.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving])
    }

    private func markerColor(_ status: Dumpster.Status) -> Color {
        switch status {
        case .available: return .green
        case .rented: return Color.ctlRed
        case .pickupToday: return .orange
        case .overdue: return .red
        }
    }
}

struct DumpsterMapLocation: Identifiable {
    let dumpster: Dumpster
    let coordinate: CLLocationCoordinate2D
    var id: UUID { dumpster.id }
}
