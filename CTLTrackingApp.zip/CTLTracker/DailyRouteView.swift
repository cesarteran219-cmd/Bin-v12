import SwiftUI
import MapKit
import CoreLocation

struct DisposalSite: Identifiable, Hashable, Codable {
    let id: UUID
    var name: String
    var address: String
    var enabled: Bool

    init(id: UUID = UUID(), name: String, address: String, enabled: Bool = true) {
        self.id = id
        self.name = name
        self.address = address
        self.enabled = enabled
    }
}

struct DailyRouteStop: Identifiable, Hashable {
    enum Kind: String, Hashable {
        case pickup
        case dump
        case delivery

        var icon: String {
            switch self {
            case .pickup: return "arrow.up.bin.fill"
            case .dump: return "trash.fill"
            case .delivery: return "arrow.down.square.fill"
            }
        }

        var titleKey: String {
            switch self {
            case .pickup: return "route_pickup"
            case .dump: return "route_dump"
            case .delivery: return "route_delivery"
            }
        }
    }

    let id: UUID
    let kind: Kind
    let title: String
    let subtitle: String
    let address: String
    let coordinate: CLLocationCoordinate2D
    let dumpsterID: UUID?
    let dumpsterNumber: String?
}

private struct RouteAction: Identifiable {
    let id = UUID()
    let kind: DailyRouteStop.Kind
    let dumpster: Dumpster
    let customerCoordinate: CLLocationCoordinate2D
    let dumpSite: GeocodedDumpSite?

    var startCoordinate: CLLocationCoordinate2D { customerCoordinate }
    var endCoordinate: CLLocationCoordinate2D { dumpSite?.coordinate ?? customerCoordinate }
}

private struct GeocodedDumpSite: Identifiable, Hashable {
    let id: UUID
    let name: String
    let address: String
    let coordinate: CLLocationCoordinate2D

    static func == (lhs: GeocodedDumpSite, rhs: GeocodedDumpSite) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}

@MainActor
final class DailyRoutePlanner: ObservableObject {
    @Published var stops: [DailyRouteStop] = []
    @Published var isPlanning = false
    @Published var message: String?
    @Published var completedStopIDs: Set<UUID> = []

    private let geocoder = CLGeocoder()

    func buildRoute(date: Date, dumpsters: [Dumpster], dumpSites: [DisposalSite], startCoordinate: CLLocationCoordinate2D?) async {
        isPlanning = true
        message = nil
        stops = []
        completedStopIDs = []
        defer { isPlanning = false }

        let calendar = Calendar.current
        let tasks = dumpsters.filter { dumpster in
            let pickup = dumpster.pickupDate.map { calendar.isDate($0, inSameDayAs: date) } ?? false
            let delivery = dumpster.dropOffDate.map { calendar.isDate($0, inSameDayAs: date) } ?? false
            return pickup || delivery
        }

        guard !tasks.isEmpty else {
            message = L10n.string("route_no_jobs")
            return
        }

        let activeDumpSites = dumpSites.filter { $0.enabled && !$0.address.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        var geocodedSites: [GeocodedDumpSite] = []
        for site in activeDumpSites {
            if let coordinate = await geocode(site.address) {
                geocodedSites.append(GeocodedDumpSite(id: site.id, name: site.name, address: site.address, coordinate: coordinate))
            }
        }

        var actions: [RouteAction] = []
        for dumpster in tasks {
            guard let address = nonEmpty(dumpster.address), let coordinate = await geocode(address) else { continue }
            let isPickup = dumpster.pickupDate.map { calendar.isDate($0, inSameDayAs: date) } ?? false
            let isDelivery = dumpster.dropOffDate.map { calendar.isDate($0, inSameDayAs: date) } ?? false

            if isPickup {
                let nearestDump = geocodedSites.min { distance(coordinate, $0.coordinate) < distance(coordinate, $1.coordinate) }
                actions.append(RouteAction(kind: .pickup, dumpster: dumpster, customerCoordinate: coordinate, dumpSite: nearestDump))
            }
            if isDelivery {
                actions.append(RouteAction(kind: .delivery, dumpster: dumpster, customerCoordinate: coordinate, dumpSite: nil))
            }
        }

        guard !actions.isEmpty else {
            message = L10n.string("route_addresses_failed")
            return
        }

        let origin = startCoordinate ?? actions.first!.startCoordinate
        let ordered = optimize(actions: actions, from: origin)
        var result: [DailyRouteStop] = []

        for action in ordered {
            let customer = nonEmpty(action.dumpster.customerName) ?? L10n.string("no_customer")
            let customerAddress = nonEmpty(action.dumpster.address) ?? ""
            let actionTitle = "\(L10n.string(action.kind.titleKey)) · \(action.dumpster.number)"
            result.append(DailyRouteStop(
                id: UUID(),
                kind: action.kind,
                title: actionTitle,
                subtitle: customer,
                address: customerAddress,
                coordinate: action.customerCoordinate,
                dumpsterID: action.dumpster.id,
                dumpsterNumber: action.dumpster.number
            ))

            if action.kind == .pickup, let site = action.dumpSite {
                result.append(DailyRouteStop(
                    id: UUID(),
                    kind: .dump,
                    title: "\(L10n.string("route_dump")) · \(site.name)",
                    subtitle: L10n.string("route_empty_before_next"),
                    address: site.address,
                    coordinate: site.coordinate,
                    dumpsterID: action.dumpster.id,
                    dumpsterNumber: action.dumpster.number
                ))
            }
        }

        stops = result
        if geocodedSites.isEmpty && actions.contains(where: { $0.kind == .pickup }) {
            message = L10n.string("route_add_dump_site_warning")
        }
    }

    func toggleComplete(_ stop: DailyRouteStop) {
        if completedStopIDs.contains(stop.id) { completedStopIDs.remove(stop.id) }
        else { completedStopIDs.insert(stop.id) }
    }

    private func optimize(actions: [RouteAction], from origin: CLLocationCoordinate2D) -> [RouteAction] {
        guard actions.count > 1 else { return actions }
        if actions.count <= 8 {
            var best = actions
            var bestScore = Double.greatestFiniteMagnitude
            var working = actions
            permute(&working, start: 0) { candidate in
                let score = routeDistance(candidate, from: origin)
                if score < bestScore {
                    bestScore = score
                    best = candidate
                }
            }
            return best
        }

        var remaining = actions
        var ordered: [RouteAction] = []
        var current = origin
        while !remaining.isEmpty {
            let nextIndex = remaining.indices.min { distance(current, remaining[$0].startCoordinate) < distance(current, remaining[$1].startCoordinate) }!
            let action = remaining.remove(at: nextIndex)
            ordered.append(action)
            current = action.endCoordinate
        }
        return ordered
    }

    private func routeDistance(_ actions: [RouteAction], from origin: CLLocationCoordinate2D) -> Double {
        var current = origin
        var total = 0.0
        for action in actions {
            total += distance(current, action.startCoordinate)
            if action.kind == .pickup, let dump = action.dumpSite {
                total += distance(action.startCoordinate, dump.coordinate)
            }
            current = action.endCoordinate
        }
        return total
    }

    private func permute(_ items: inout [RouteAction], start: Int, visit: ([RouteAction]) -> Void) {
        if start == items.count { visit(items); return }
        for index in start..<items.count {
            items.swapAt(start, index)
            permute(&items, start: start + 1, visit: visit)
            items.swapAt(start, index)
        }
    }

    private func distance(_ a: CLLocationCoordinate2D, _ b: CLLocationCoordinate2D) -> CLLocationDistance {
        CLLocation(latitude: a.latitude, longitude: a.longitude).distance(from: CLLocation(latitude: b.latitude, longitude: b.longitude))
    }

    private func geocode(_ address: String) async -> CLLocationCoordinate2D? {
        do {
            let placemarks = try await geocoder.geocodeAddressString(address)
            return placemarks.first?.location?.coordinate
        } catch {
            return nil
        }
    }

    private func nonEmpty(_ value: String?) -> String? {
        guard let value else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }
}

@MainActor
final class RouteLocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var coordinate: CLLocationCoordinate2D?
    @Published var authorizationDenied = false

    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
    }

    func requestLocation() {
        switch manager.authorizationStatus {
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse:
            manager.requestLocation()
        default:
            authorizationDenied = true
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
            manager.requestLocation()
        } else if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
            authorizationDenied = true
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        coordinate = locations.last?.coordinate
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) { }
}

struct DailyRouteView: View {
    @EnvironmentObject private var store: DumpsterStore
    @StateObject private var planner = DailyRoutePlanner()
    @StateObject private var locationManager = RouteLocationManager()
    @State private var routeDate = Date()

    var body: some View {
        List {
            Section {
                DatePicker("route_date", selection: $routeDate, displayedComponents: .date)
                Button {
                    locationManager.requestLocation()
                    Task {
                        try? await Task.sleep(for: .milliseconds(450))
                        await planner.buildRoute(date: routeDate, dumpsters: store.dumpsters, dumpSites: store.disposalSites, startCoordinate: locationManager.coordinate)
                    }
                } label: {
                    Label(planner.isPlanning ? L10n.string("route_planning") : L10n.string("route_optimize"), systemImage: "point.topleft.down.to.point.bottomright.curvepath")
                }
                .disabled(planner.isPlanning)
            } footer: {
                Text("route_optimizer_help")
            }

            if planner.isPlanning {
                Section { HStack { ProgressView(); Text("route_planning") } }
            }

            if let message = planner.message {
                Section { Text(message).foregroundStyle(.secondary) }
            }

            if !planner.stops.isEmpty {
                Section("route_today") {
                    ForEach(Array(planner.stops.enumerated()), id: \.element.id) { index, stop in
                        RouteStopRow(index: index + 1, stop: stop, completed: planner.completedStopIDs.contains(stop.id)) {
                            planner.toggleComplete(stop)
                        }
                    }
                }
            }
        }
        .navigationTitle("route_title")
        .ctlLogoToolbar()
        .task {
            locationManager.requestLocation()
            try? await Task.sleep(for: .milliseconds(350))
            await planner.buildRoute(date: routeDate, dumpsters: store.dumpsters, dumpSites: store.disposalSites, startCoordinate: locationManager.coordinate)
        }
        .onChange(of: routeDate) { _, newDate in
            Task { await planner.buildRoute(date: newDate, dumpsters: store.dumpsters, dumpSites: store.disposalSites, startCoordinate: locationManager.coordinate) }
        }
    }
}

private struct RouteStopRow: View {
    let index: Int
    let stop: DailyRouteStop
    let completed: Bool
    let onToggleComplete: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .top) {
                ZStack {
                    Circle().fill(completed ? Color.green : Color.ctlRed).frame(width: 32, height: 32)
                    Text("\(index)").font(.caption.bold()).foregroundStyle(.white)
                }
                VStack(alignment: .leading, spacing: 3) {
                    Label(stop.title, systemImage: stop.kind.icon).font(.headline)
                    if !stop.subtitle.isEmpty { Text(stop.subtitle).font(.subheadline).foregroundStyle(.secondary) }
                    Text(stop.address).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
            }

            HStack {
                Button {
                    openInAppleMaps(stop)
                } label: {
                    Label("route_navigate", systemImage: "location.fill")
                }
                .buttonStyle(.borderedProminent)
                .tint(Color.ctlRed)

                Button(action: onToggleComplete) {
                    Label(completed ? L10n.string("route_undo") : L10n.string("route_done"), systemImage: completed ? "arrow.uturn.backward" : "checkmark.circle")
                }
                .buttonStyle(.bordered)
            }
        }
        .padding(.vertical, 6)
    }

    private func openInAppleMaps(_ stop: DailyRouteStop) {
        let item = MKMapItem(placemark: MKPlacemark(coordinate: stop.coordinate))
        item.name = stop.title
        item.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving])
    }
}

struct DisposalSiteManagerView: View {
    @EnvironmentObject private var store: DumpsterStore
    @State private var showingAdd = false

    var body: some View {
        List {
            if store.disposalSites.isEmpty {
                ContentUnavailableView("route_no_dump_sites", systemImage: "trash", description: Text("route_no_dump_sites_help"))
            }
            ForEach(store.disposalSites) { site in
                NavigationLink {
                    DisposalSiteEditorView(site: site)
                } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack { Text(site.name).font(.headline); Spacer(); if site.enabled { Image(systemName: "checkmark.circle.fill").foregroundStyle(.green) } }
                        Text(site.address).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            .onDelete { offsets in
                for index in offsets { store.deleteDisposalSite(store.disposalSites[index]) }
            }
        }
        .navigationTitle("route_dump_sites")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showingAdd = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(isPresented: $showingAdd) {
            NavigationStack { DisposalSiteEditorView(site: nil) }
        }
    }
}

struct DisposalSiteEditorView: View {
    @EnvironmentObject private var store: DumpsterStore
    @Environment(\.dismiss) private var dismiss
    let site: DisposalSite?

    @State private var name: String
    @State private var address: String
    @State private var enabled: Bool

    init(site: DisposalSite?) {
        self.site = site
        _name = State(initialValue: site?.name ?? "")
        _address = State(initialValue: site?.address ?? "")
        _enabled = State(initialValue: site?.enabled ?? true)
    }

    var body: some View {
        Form {
            Section("route_dump_site") {
                TextField("route_dump_site_name", text: $name)
                TextField("address", text: $address, axis: .vertical)
                Toggle("route_dump_site_enabled", isOn: $enabled)
            }
            if let site {
                Section { Button("route_delete_dump_site", role: .destructive) { store.deleteDisposalSite(site); dismiss() } }
            }
        }
        .navigationTitle(site == nil ? L10n.string("route_add_dump_site") : L10n.string("route_edit_dump_site"))
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("cancel") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("save") { save() }.disabled(name.trimmingCharacters(in: .whitespaces).isEmpty || address.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }

    private func save() {
        if let site {
            var updated = site
            updated.name = name
            updated.address = address
            updated.enabled = enabled
            store.updateDisposalSite(updated)
        } else {
            store.addDisposalSite(DisposalSite(name: name, address: address, enabled: enabled))
        }
        dismiss()
    }
}
